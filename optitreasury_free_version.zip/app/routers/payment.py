from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database.connection import SessionLocal
from app.models.payment import Payment

router = APIRouter(prefix="/payments", tags=["Payments"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/")
def create_payment(amount: float, status: str, company_id: int, db: Session = Depends(get_db)):
    payment = Payment(amount=amount, status=status, company_id=company_id)
    db.add(payment)
    db.commit()
    db.refresh(payment)
    return payment

@router.get("/company/{company_id}")
def get_company_payments(company_id: int, db: Session = Depends(get_db)):
    return db.query(Payment).filter(Payment.company_id == company_id).all()