from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database.connection import SessionLocal
from app.models.company import Company

router = APIRouter(prefix="/companies", tags=["Companies"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/")
def create_company(name: str, db: Session = Depends(get_db)):
    new_company = Company(name=name)
    db.add(new_company)
    db.commit()
    db.refresh(new_company)
    return new_company