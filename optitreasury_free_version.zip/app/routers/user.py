from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database.connection import SessionLocal
from app.models.user import User

router = APIRouter(prefix="/users", tags=["Users"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/")
def create_user(email: str, company_id: int, db: Session = Depends(get_db)):
    user = User(email=email, company_id=company_id)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user