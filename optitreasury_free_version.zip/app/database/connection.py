from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_URL = "postgresql://optitreasury_db_user:3TX4fyuNaApfFIw81wwsbFtyK4cOBVMU@dpg-d0jp51odl3ps73co7490-a.frankfurt-postgres.render.com/optitreasury_db"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

def create_db():
    from app.models import company, user, payment
    Base.metadata.create_all(bind=engine)